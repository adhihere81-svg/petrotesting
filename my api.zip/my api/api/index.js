// api/index.js
const mongoose = require('mongoose');

module.exports = async (req, res) => {
    // 1. Database connection check
    if (!mongoose.connections[0].readyState) {
        await mongoose.connect(process.env.DATABASE_URL);
    }

    // 2. Simple API Response
    res.status(200).json({ 
        status: "Success", 
        message: "Database-മായി കണക്ട് ആയിട്ടുണ്ട്!" 
    });
};
